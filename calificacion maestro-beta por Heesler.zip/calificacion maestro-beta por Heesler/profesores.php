<?php 

	require_once("modules/profesores/controllers/teachers_controller.php");

?>