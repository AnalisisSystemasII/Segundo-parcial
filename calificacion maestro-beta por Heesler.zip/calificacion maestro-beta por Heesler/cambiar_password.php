<?php 

	require_once("controllers/change_password_controller.php");

?>