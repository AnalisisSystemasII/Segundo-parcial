<?php  

	require_once("controllers/main_controller.php");

?>