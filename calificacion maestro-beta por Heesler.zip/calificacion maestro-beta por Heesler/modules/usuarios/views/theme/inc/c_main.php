<div class="content-txt">
	<?php echo $schoolName;?>
</div>
		
	