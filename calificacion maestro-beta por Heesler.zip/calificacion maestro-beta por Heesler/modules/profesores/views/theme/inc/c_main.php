<h2 class="title-page">Bienvenido <?php echo $userName;?></h2>

<p>Lista de grupos asignados:</p>

<div class="groups-tableContainer">
	
	<div class="groups-tableWrap">
	
		<table class="groups-table">
			<?php  
				
				echo $content;

			?>
		</table>
	
	</div>

</div>