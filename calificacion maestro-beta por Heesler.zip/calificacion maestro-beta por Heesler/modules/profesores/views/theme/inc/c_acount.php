<h1 class="title-page">Cuenta</h1>

<div id="set-formWrap" class="set-formWrap">
			
        <form action="" method="post" id="set-form" class="set-form">
        
            <h2 class="header-form">Actualizar datos</h2>

            <div class="ajax-msgPage" id="ajax-msgPage"></div>          	

            <div class="controls-wrap">   

                <?php echo $setForm;//imprimir controles ?>
            
           	</div>
        
            <div class="btns-container">
        	
        	 	<input type="submit" name="set-btn" id="set-dataBtn" class="action-formBtn" value="Actualizar" tabindex="9">
        
            </div>
        
        </form>

</div>
            