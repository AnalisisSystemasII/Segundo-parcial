<?php 

	require_once("modules/grupos/controllers/groups_controller.php");

?>