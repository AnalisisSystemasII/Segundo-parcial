<?php 

	//Datos de conexion con servidor 
	define("DB", "sistema_escolar_2");
	define("HOST", "localhost");
	define("USER", "root");
	define("PASSWORD", "");

?>