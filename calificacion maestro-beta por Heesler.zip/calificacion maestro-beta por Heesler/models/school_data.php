<?php  
	
	$schoolData = $_SESSION['userCA']['schoolData'];;

	$schoolId = $schoolData['id'];
	$schoolName= $schoolData['name'];
    $schoolAddress = $schoolData['address'];
    $schoolCity = $schoolData['city'];
    $schoolTelephone = $schoolData['telephone'];
    $schoolCountry = $schoolData['country'];
    $schoolWeb = $schoolData['web'];
    $schoolEmail = $schoolData['email'];
    $schoolAddDate = $schoolData['addDate'];
    $schooSetDate = $schoolData['setDate'];

?>
