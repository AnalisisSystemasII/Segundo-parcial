<?php 

	require_once("modules/colegio/controllers/info_school_controller.php");

?>