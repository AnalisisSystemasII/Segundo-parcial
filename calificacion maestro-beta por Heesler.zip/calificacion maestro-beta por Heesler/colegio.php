<?php  

	require_once("modules/colegio/controllers/school_controller.php");

?>